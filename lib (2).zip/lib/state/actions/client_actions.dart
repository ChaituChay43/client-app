class SetClientIdAction {
  final String clientId;
  SetClientIdAction(this.clientId);
}
