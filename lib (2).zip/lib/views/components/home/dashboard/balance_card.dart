import 'package:amplify/constants/asset_paths.dart';
import 'package:amplify/models/other/account_data.dart';
import 'package:amplify/models/other/balance_details.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class BalanceCard extends StatelessWidget {
  final Account account;

  const BalanceCard({super.key, required this.account});

  @override
  Widget build(BuildContext context) {
    final double totalBalance = account.totalBalance;
    final BalanceDetails today = account.today;
    final BalanceDetails mtd = account.mtd;
    final BalanceDetails qtd = account.qtd;
    final BalanceDetails tyd = account.ytd;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Total Balance',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              Row(
                children: [
                  SvgPicture.asset(AssetPaths.accountDetailsMoney),
                  const SizedBox(width: 10.0),
                  Text(
                    '\$${totalBalance.toStringAsFixed(2)}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                  ),
                ],
              ),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('Today', '\$${today.value.toStringAsFixed(2)}', '${(today.percentage * 100).toStringAsFixed(2)}%'),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('MTD', '\$${mtd.value.toStringAsFixed(2)}', '${(mtd.percentage * 100).toStringAsFixed(2)}%'),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('QTD', '\$${qtd.value.toStringAsFixed(2)}', '${(qtd.percentage * 100).toStringAsFixed(2)}%'),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('YTD', '\$${tyd.value.toStringAsFixed(2)}', '${(tyd.percentage * 100).toStringAsFixed(2)}%'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget balanceCard(String title, String amount, String percentage) {
    return Container(
      width: 150.0,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 20.0),
          ),
          const SizedBox(height: 10.0),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                amount,
                style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 10.0),
              Container(
                padding: const EdgeInsets.all(4.0),
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  color: Color(0xFFEBF7ED),
                ),
                child: Text(
                  percentage,
                  style: const TextStyle(
                    fontSize: 10.0,
                    color: Color(0xFF077D55),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
