// import 'package:flutter/material.dart';
// import 'package:fl_chart/fl_chart.dart';

// class HistoryGraph extends StatefulWidget {
//   const HistoryGraph({super.key});

//   @override
//   _HistoryGraphState createState() => _HistoryGraphState();
// }

// class _HistoryGraphState extends State<HistoryGraph> {
//   String selectedRange = 'ALL';

//   final List<Map<String, dynamic>> data = [
//     {"monthStart": 0, "emv": 3.14}, // April 18
//     {"monthStart": 1, "emv": 3.15},
//     {"monthStart": 2, "emv": 3.17},
//     {"monthStart": 3, "emv": 3.21},
//     {"monthStart": 4, "emv": 3.27},
//     {"monthStart": 5, "emv": 3.32},
//     {"monthStart": 6, "emv": 3.30},
//     {"monthStart": 7, "emv": 3.14},
//     {"monthStart": 8, "emv": 3.15},
//     {"monthStart": 9, "emv": 2.99},
//     {"monthStart": 10, "emv": 3.11},
//     {"monthStart": 11, "emv": 3.14},
//     {"monthStart": 12, "emv": 3.18},
//     {"monthStart": 13, "emv": 3.25},
//     {"monthStart": 14, "emv": 3.12},
//     {"monthStart": 15, "emv": 3.22},
//     {"monthStart": 16, "emv": 3.25},
//     {"monthStart": 17, "emv": 3.21},
//     {"monthStart": 18, "emv": 3.22}, // Oct 19
//     {"monthStart": 19, "emv": 5.27}, // Nov 19
//     {"monthStart": 20, "emv": 5.49},
//     {"monthStart": 21, "emv": 6.27},
//     {"monthStart": 22, "emv": 6.04},
//     {"monthStart": 23, "emv": 6.07},
//     {"monthStart": 24, "emv": 6.79},
//     {"monthStart": 25, "emv": 6.94},
//     {"monthStart": 26, "emv": 8.17},
//     {"monthStart": 27, "emv": 8.47},
//     {"monthStart": 28, "emv": 8.27}, // Oct 20
//   ];

//   List<FlSpot> chartData = [];

//   @override
//   void initState() {
//     super.initState();
//     updateChartData('ALL');
//   }

//   void updateChartData(String range) {
//     setState(() {
//       selectedRange = range;
//       // Clear the existing chart data
//       chartData.clear();

//       // Create FlSpot data based on the data array
//       if (range == 'ALL') {
//         for (var entry in data) {
//           chartData.add(FlSpot(entry['monthStart'].toDouble(), entry['emv']));
//         }
//       } 
//       // Logic for 'YTD'
//       else if (range == 'YTD') {
//         for (var i = 20; i <= 28; i++) {
//           chartData.add(FlSpot(i.toDouble(), data[i]['emv']));
//         }
//       } 
//       // Logic for '1Y'
//       else if (range == '1Y') {   
//          for (var i = 17; i <= 28; i++) {
//           chartData.add(FlSpot(i.toDouble(), data[i]['emv']));
//         }
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(20.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Text(
//             "Portfolio Balance History",
//             style: TextStyle(
//               fontFamily: "Roboto",
//               fontSize: 20.0,
//               color: Colors.black,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           // Buttons for selecting time range
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.start,
//               children: [
//                 ElevatedButton(
//                   onPressed: () => updateChartData('YTD'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: selectedRange == 'YTD' ? Colors.blue : Colors.grey,
//                   ),
//                   child: const Text("YTD"),
//                 ),
//                 const SizedBox(width: 8),
//                 ElevatedButton(
//                   onPressed: () => updateChartData('1Y'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: selectedRange == '1Y' ? Colors.blue : Colors.grey,
//                   ),
//                   child: const Text("1Y"),
//                 ),
//                 const SizedBox(width: 8),
//                 ElevatedButton(
//                   onPressed: () => updateChartData('ALL'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: selectedRange == 'ALL' ? Colors.blue : Colors.grey,
//                   ),
//                   child: const Text("ALL"),
//                 ),
//               ],
//             ),
//           ),
//           // Chart displaying data
//           Expanded(
//             child: Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: LineChart(
//                 LineChartData(
//                   lineBarsData: [
//                     LineChartBarData(
//                       spots: chartData,
//                       isCurved: false,
//                       color: Colors.blue,
//                       barWidth: 3,
//                       belowBarData: BarAreaData(
//                         show: true,
//                         color: Colors.blue.withOpacity(0.3),
//                       ),
//                       dotData: const FlDotData(show: false),
//                     ),
//                   ],
//                   titlesData: FlTitlesData(
//                     show: true,
//                     topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
//                     rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
//                     bottomTitles: AxisTitles(
//                       sideTitles: SideTitles(
//                         showTitles: true,
//                         getTitlesWidget: (value, meta) {
//                           // Get titles based on the selected range
//                           if (selectedRange == 'ALL') {
//                             return Text(
//                               data[value.toInt()]['monthStart'].toString(), // Assuming monthStart is the x-axis
//                               style: const TextStyle(color: Colors.black),
//                             );
//                           } else if (selectedRange == 'YTD') {
//                             return Text(
//                               data[value.toInt()]['monthStart'].toString(),
//                               style: const TextStyle(color: Colors.black),
//                             );
//                           } else if (selectedRange == '1Y') {
//                             return Text(
//                               data[value.toInt()]['monthStart'].toString(),
//                               style: const TextStyle(color: Colors.black),
//                             );
//                           }
//                           return const Text('');
//                         },
//                       ),
//                     ),
//                     leftTitles: AxisTitles(
//                       sideTitles: SideTitles(
//                         showTitles: true,
//                         reservedSize: 40,
//                         interval: 2.5, // Set the interval to 2.5
//                         getTitlesWidget: (value, meta) {
//                           return Text(
//                             value.toString(), // Just display the value
//                             style: const TextStyle(color: Colors.black),
//                           );
//                         },
//                       ),
//                     ),

//                   ),
//                   borderData: FlBorderData(
//                     show: true,
//                     border: Border.all(color: Colors.grey),
//                   ),
//                   gridData: const FlGridData(show: true),
//                   minX: selectedRange == 'ALL' ? 0 : (selectedRange == 'YTD' ? 20 : 17),
//                   maxX: selectedRange == 'ALL' ? data.length.toDouble() - 1 : 28,
//                   minY: 0,
//                   maxY: 10,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class HistoryGraph extends StatefulWidget {
  const HistoryGraph({super.key});

  @override
  _HistoryGraphState createState() => _HistoryGraphState();
}

class _HistoryGraphState extends State<HistoryGraph> {
  String selectedRange = 'ALL';

final List<Map<String, dynamic>> data = [
  {"monthStart": 0, "emv": 3.14, "formattedDate": "Apr 18"}, // April 18
  {"monthStart": 1, "emv": 3.15, "formattedDate": "May 18"}, // May 18
  {"monthStart": 2, "emv": 3.17, "formattedDate": "Jun 18"}, // June 18
  {"monthStart": 3, "emv": 3.21, "formattedDate": "Jul 18"}, // July 18
  {"monthStart": 4, "emv": 3.27, "formattedDate": "Aug 18"}, // August 18
  {"monthStart": 5, "emv": 3.32, "formattedDate": "Sep 18"}, // September 18
  {"monthStart": 6, "emv": 3.30, "formattedDate": "Oct 18"}, // October 18
  {"monthStart": 7, "emv": 3.14, "formattedDate": "Nov 18"}, // November 18
  {"monthStart": 8, "emv": 3.15, "formattedDate": "Dec 18"}, // December 18
  {"monthStart": 9, "emv": 2.99, "formattedDate": "Jan 19"}, // January 19
  {"monthStart": 10, "emv": 3.11, "formattedDate": "Feb 19"}, // February 19
  {"monthStart": 11, "emv": 3.14, "formattedDate": "Mar 19"}, // March 19
  {"monthStart": 12, "emv": 3.18, "formattedDate": "Apr 19"}, // April 19
  {"monthStart": 13, "emv": 3.25, "formattedDate": "May 19"}, // May 19
  {"monthStart": 14, "emv": 3.12, "formattedDate": "Jun 19"}, // June 19
  {"monthStart": 15, "emv": 3.22, "formattedDate": "Jul 19"}, // July 19
  {"monthStart": 16, "emv": 3.25, "formattedDate": "Aug 19"}, // August 19
  {"monthStart": 17, "emv": 3.23, "formattedDate": "Sep 19"}, // September 19
  {"monthStart": 18, "emv": 3.23, "formattedDate": "Oct 19"}, // October 19
  {"monthStart": 19, "emv": 3.22, "formattedDate": "Nov 19"}, // November 19
  {"monthStart": 20, "emv": 5.27, "formattedDate": "Dec 19"}, // December 19
  {"monthStart": 21, "emv": 5.30, "formattedDate": "Jan 20"}, // January 20
  {"monthStart": 22, "emv": 5.49, "formattedDate": "Feb 20"}, // February 20
  {"monthStart": 23, "emv": 6.27, "formattedDate": "Mar 20"}, // March 20
  {"monthStart": 24, "emv": 6.04, "formattedDate": "Apr 20"}, // April 20
  {"monthStart": 25, "emv": 6.07, "formattedDate": "May 20"}, // May 20
  {"monthStart": 26, "emv": 6.79, "formattedDate": "Jun 20"}, // June 20
  {"monthStart": 27, "emv": 6.94, "formattedDate": "Jul 20"}, // July 20
  {"monthStart": 28, "emv": 8.17, "formattedDate": "aug 20"}, //a
   {"monthStart": 29, "emv":8.47, "formattedDate": "sep 20"}, // May 20
  {"monthStart": 30, "emv": 8.27, "formattedDate": "oct 20"}, // June 20
];


  List<FlSpot> chartData = [];
   String? previousMonthStart;

  @override
  void initState() {
    super.initState();
    updateChartData('ALL');
  }

  void updateChartData(String range) {
    setState(() {
      selectedRange = range;
      chartData.clear();

      if (range == 'ALL') {
        for (var entry in data) {
          chartData.add(FlSpot(entry['monthStart'].toDouble(), entry['emv']));
        }
      } else if (range == 'YTD') {
        for (var i = 21; i <= 30; i++) {
          chartData.add(FlSpot(i.toDouble(), data[i]['emv']));
        }
      } else if (range == '1Y') {
        for (var i = 18; i <= 30; i++) {
          chartData.add(FlSpot(i.toDouble(), data[i]['emv']));
        }
      }
    });
  }

  @override
 @override
Widget build(BuildContext context) {
  return Container(
    padding: const EdgeInsets.all(20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Portfolio Balance History",
          style: TextStyle(
            fontFamily: "Roboto",
            fontSize: 20.0,
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
       Padding(
  padding: const EdgeInsets.all(8.0),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.start,
    children: [
      const SizedBox(width: 50.0),
      const Text(
        "zoom",
        style: TextStyle(color: Colors.grey, fontSize: 12.0, fontWeight: FontWeight.bold),
      ),
      const SizedBox(width: 8.0),
      OutlinedButton(
        onPressed: () => updateChartData('YTD'),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 20.0), // Adjust padding to reduce size
          backgroundColor: selectedRange == 'YTD' ? const Color.fromRGBO(16, 58, 117, 1) : Colors.white,
          side: const BorderSide(
            color: Color.fromRGBO(16, 58, 117, 1), // Border color
            width: 2.0, // Border width
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0), // Optional: to make the button corners rounded
          ),
        ),
        child: Text(
          "YTD",
          style: TextStyle(
            color: selectedRange == 'YTD' ? Colors.white : const Color.fromRGBO(16, 58, 117, 1), // Text color
            fontWeight: FontWeight.bold, // Bold text
            fontSize: 10.0
          ),
        ),
      ),
      const SizedBox(width: 8),
      OutlinedButton(
        onPressed: () => updateChartData('1Y'),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 20.0), // Adjust padding to reduce size
          backgroundColor: selectedRange == '1Y' ? const Color.fromRGBO(16, 58, 117, 1) : Colors.white,
          side: const BorderSide(
            color: Color.fromRGBO(16, 58, 117, 1), // Border color
            width: 2.0, // Border width
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0), // Optional: to make the button corners rounded
          ),
        ),
        child: Text(
          "1Y",
          style: TextStyle(
            color: selectedRange == '1Y' ? Colors.white : const Color.fromRGBO(16, 58, 117, 1), // Text color
            fontWeight: FontWeight.bold, 
            fontSize: 10.0// Bold text
          ),
        ),
      ),
      const SizedBox(width: 8),
      OutlinedButton(
        onPressed: () => updateChartData('ALL'),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 20.0), // Adjust padding to reduce size
          backgroundColor: selectedRange == 'ALL' ? const Color.fromRGBO(16, 58, 117, 1) : Colors.white,
          side: const BorderSide(
            color: Color.fromRGBO(16, 58, 117, 1), // Border color
            width: 2.0, // Border width
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0), // Optional: to make the button corners rounded
          ),
        ),
        child: Text(
          "ALL",
          style: TextStyle(
            color: selectedRange == 'ALL' ? Colors.white : const Color.fromRGBO(16, 58, 117, 1), // Text color
            fontWeight: FontWeight.bold,
            fontSize: 10.0 // Bold text
          ),
        ),
      ),
    ],
  ),
),
Expanded(
  child: Padding(
    padding: const EdgeInsets.all(8.0),
    child: LineChart(
      LineChartData(
        lineBarsData: [
          LineChartBarData(
            spots: chartData,
            isCurved: false,
            color: const Color.fromRGBO(61, 141, 245, 1.0),
            barWidth: 3,
            belowBarData: BarAreaData(
              show: true,
              color: const Color.fromRGBO(212, 228, 250, 0.75),
            ),
            dotData: const FlDotData(
              show: false,
            ),
          ),
        ],
        titlesData: FlTitlesData(
          show: true,
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                if (value.toInt() < data.length) {
                  String currentMonthStart = data[value.toInt()]['monthStart'].toString();
                  String label = data[value.toInt()]['formattedDate'].toString();

                  if (selectedRange == 'ALL') {
                    if (value.toInt() == 0) {
                      return const Text(''); // Skip the first label
                    }
                    if (value.toInt() % 3 != 0) {
                      return const Text(''); // Return an empty Text to skip non-4th labels
                    } else {
                      return Column(
                        children: [
                          const Text("|",style: TextStyle(color:Color(0xFF666666),
                            fontSize: 8.0,)),
                          Text(
                            label,
                            style: const TextStyle(  color: Color(0xFF666666),
                            fontSize: 9.0,),
                          ),
                        ],
                      );
                    }
                  }
                  if (selectedRange == '1Y' || selectedRange == 'YTD') {
                    // Check if the current monthStart is the same as the previous one
                    if (previousMonthStart == currentMonthStart) {
                      return const Text(''); // Return an empty Text to avoid duplication
                    }
                    // Update previousMonthStart to the current one
                    previousMonthStart = currentMonthStart;

                    // Return the current monthStart as Text
                    return Column(
                        children: [
                          const Text("|",style: TextStyle(color:Color(0xFF666666),
                            fontSize: 8.0,)),
                          Text(
                            label,
                            style: const TextStyle(  color: Color(0xFF666666),
                            fontSize: 9.0,),
                          ),
                        ],
                      );
                  }
                }
                return const Text('');
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 50,
              interval: 2.5, // Set the interval size to 2.5
              getTitlesWidget: (value, meta) {
                return Column(
                  children: [
                    Text(
                      '${value.toStringAsFixed(1)}0M', // Append 'M' to the value
                      style: const TextStyle(
                        color: Color(0xFF666666),
                        fontSize: 10.0,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        borderData: FlBorderData(
          show: true,
          border: const Border(
            top: BorderSide(color: Colors.grey, width: 0), // Visible top border
            bottom: BorderSide(color: Colors.transparent, width: 0), // Hide bottom border
            left: BorderSide(color: Colors.transparent, width: 0), // Hide left border
            right: BorderSide(color: Colors.transparent, width: 0), // Hide right border
          ),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (value) {
            return const FlLine(color: Colors.grey, strokeWidth: 0.2); // Make grid lines finer
          },
          getDrawingVerticalLine: (value) {
            return const FlLine(color: Colors.grey, strokeWidth: 0);
          },
        ),
        minX: selectedRange == 'ALL' ? 0 : (selectedRange == 'YTD' ? 21 : 18),
        maxX: selectedRange == 'ALL' ? data.length.toDouble() - 1 : 30,
        minY: 0,
        maxY: 10,
      ),
    ),
  ),
),
      ],
    ),
  );
}

}
