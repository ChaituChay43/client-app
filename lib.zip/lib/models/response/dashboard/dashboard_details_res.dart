class DashboardDetails {
  // A map to hold dynamic properties
  final Map<String, dynamic> _properties;

  // Constructor to initialize the properties
  DashboardDetails({Map<String, dynamic>? properties})
      : _properties = properties ?? {};

  // Method to get a property
  dynamic getProperty(String key) {
    return _properties[key];
  }

  // Method to set a property
  void setProperty(String key, dynamic value) {
    _properties[key] = value;
  }

  // Factory constructor for creating an instance from JSON
  factory DashboardDetails.fromJson(Map<String, dynamic> json) {
    return DashboardDetails(properties: json);
  }

  // Method to convert the object back to JSON
  Map<String, dynamic> toJson() {
    return _properties;
  }
}
