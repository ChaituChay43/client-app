class BaseRes {
  BaseRes();

  BaseRes.fromJson(Map<String, dynamic> json);

}
