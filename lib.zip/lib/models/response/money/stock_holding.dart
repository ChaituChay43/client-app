class StockHolding {
  final String symbol;
  final String companyName;
  final double? latestPrice;
  final double? marketCap;
  final String? assetClass;
  double? percOfBook; // Change from final to non-final
  final double? open;

  StockHolding({
    required this.symbol,
    required this.companyName,
    this.latestPrice,
    this.marketCap,
    this.assetClass,
    this.percOfBook,
    this.open,
  });

  // Factory method to create a StockHolding from JSON
  factory StockHolding.fromJson(Map<String, dynamic> json) {
    return StockHolding(
      symbol: json['symbol'],
      companyName: json['companyName'],
      latestPrice: json['latestPrice']?.toDouble(),
      open: json['open']?.toDouble(),
      marketCap: json['marketCap']?.toDouble(),
      assetClass: json['assetClass'],
      percOfBook: null, // Initialize as null
    );
  }

  // Method to convert StockHolding to JSON for possible future use
  Map<String, dynamic> toJson() {
    return {
      'symbol': symbol,
      'companyName': companyName,
      'latestPrice': latestPrice,
      'marketCap': marketCap,
      'assetClass': assetClass,
      'open': open,
      'percOfBook': percOfBook, // Include percOfBook in JSON
    };
  }
}
