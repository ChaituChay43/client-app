class StockData {
  final String symbol;
  final String name;
  final String value;
  final String percentage;

  StockData({
    required this.symbol,
    required this.name,
    required this.value,
    required this.percentage,
  });

  // Factory method to create an instance from a map
  factory StockData.fromMap(Map<String, dynamic> map) {
    return StockData(
      symbol: map['Symbol'] as String,
      name: map['Name'] as String,
      value: map['Value'] as String,
      percentage: map['percentage'] as String,
    );
  }

  // Convert the instance to a map
  Map<String, dynamic> toMap() {
    return {
      'Symbol': symbol,
      'Name': name,
      'Value': value,
      'percentage': percentage,
    };
  }
}
