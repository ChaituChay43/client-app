class AssetData {
  final String name;
  final String value;
  final double percentage;

  AssetData({
    required this.name,
    required this.value,
    required this.percentage,
  });

  // Factory method to create an instance from a map
  factory AssetData.fromMap(Map<String, dynamic> map) {
    return AssetData(
      name: map['Name'] as String,
      value: map['Value'] as String,
      percentage: map['percentage'] as double,
    );
  }

  // Convert the instance to a map
  Map<String, dynamic> toMap() {
    return {
      'Name': name,
      'Value': value,
      'percentage': percentage,
    };
  }
}
