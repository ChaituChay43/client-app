import 'package:amplify/data/services/base_service.dart';
import 'package:amplify/models/response/money/stock_holding.dart';

class MoneyService extends BaseService {
  // List of symbols to fetch stock holdings for
  final List<String> defaultSymbols = [
    "BND",
    "NTBIX",
    "AOA",
    "DFDIX",
    "MADCX",
    "BISIX",
    "F",
    "GM",
    "ORLY",
    "RIVN"
  ];

Future<List<StockHolding>> fetchStockHoldings({List<String>? symbols}) async {
  try {
    // Use provided symbols or default to the predefined list
    final List<String> symbolsToUse = symbols ?? defaultSymbols;

    String url = '$baseUrl/market/stock/stats';

    // Send the POST request with symbols
    BaseResModel baseRes = await doPostData(url, symbolsToUse);

    // Ensure the response contains the expected data
    if (baseRes.data != null) {
      // Parse the response and create a list of StockHolding instances
      List<StockHolding> stockHoldings = (baseRes.data as List)
          .map((json) => StockHolding.fromJson(json))
          .toList();

      // Update percOfBook value for each StockHolding
      for (var holding in stockHoldings) {
        if (holding.latestPrice != null && holding.open != null && holding.open != 0) {
          holding.percOfBook = ((holding.latestPrice! - holding.open!) / holding.open!) * 100; // Calculate percentage change
        } else {
          holding.percOfBook = null; // Assign null if values are not available
        }
      }

      return stockHoldings;
    } else {
      throw ApiException(message: 'No data found in response', statusCode: 204);
    }
  } catch (e) {
    throw ApiException(message: 'Error fetching stock holdings: ${e.toString()}', statusCode: 500);
  }
}

}
