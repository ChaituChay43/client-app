import 'package:amplify/blocs/auth/auth_repository.dart';
import 'package:amplify/data/services/base_service.dart';

class DashboardService extends BaseService {
  final AuthRepository _authRepository = AuthRepository();

  // Fetches the Dashboard full details
  Future<dynamic> fetchDashHouseholdItemsInfo() async {
    try {
      var clientId = await _authRepository.getClientId();
      // Constructing the URL for the API request
      String url = '$baseUrl/client/$clientId/ext-data/FACTFINDER';

      // Performing the GET request
      BaseResModel baseRes = await doGet(url);

      return baseRes.data;
      
    } catch (e) {
      // Print the error for debugging
      print('Error fetching Dashboard details: $e');
      // Re-throwing the exception to be handled by the caller
      throw Exception('Error fetching Dashboard details: $e');
    }
  }
}
