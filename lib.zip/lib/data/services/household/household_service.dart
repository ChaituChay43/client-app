import 'package:amplify/blocs/auth/auth_repository.dart';
import 'package:amplify/data/services/base_service.dart';
import 'package:amplify/models/response/household/household_res.dart';

class HouseholdService extends BaseService {
  final AuthRepository _authRepository = AuthRepository();

  // Fetches the household full details
  Future<HouseholdDetail> fetchHouseholdFullDetails() async {
    try {
      var clientId = await _authRepository.getClientId();
      String url = '$baseUrl/client/$clientId/full-detail';
      BaseResModel baseRes = await doGet(url);

      // Check if the response contains data
      if (baseRes.data != null) {
        return HouseholdDetail.fromJson(baseRes.data); // Use 'data' from BaseResModel
      } else {
        throw Exception('No data found in response');
      }
    } catch (e) {
      throw Exception('Error fetching household details: $e');
    }
  }
}
