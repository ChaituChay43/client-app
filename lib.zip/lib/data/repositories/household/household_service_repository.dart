import 'package:amplify/data/services/household/household_service.dart';
import 'package:amplify/models/response/household/household_res.dart';

class HouseholdServiceRepository {
  final HouseholdService _householdService;

  HouseholdServiceRepository(this._householdService);

  Future<HouseholdDetail> fetchHouseholdDetails() async {
    try {
      return await _householdService.fetchHouseholdFullDetails();
    } catch (e) {
      print("Error fetching household details in repository: ${e.toString()}");
      throw Exception('Failed to load household details: $e');
    }
  }
}