import 'package:amplify/data/services/money/money_service.dart';
import 'package:amplify/models/response/money/stock_holding.dart';

class MoneyServiceRepository {
  final MoneyService _moneyService = MoneyService();

  // Caching variables
  List<StockHolding>? cachedStockHoldings; // Cache for stock holdings
  DateTime? cacheTime; // Cache time


  Future<List<StockHolding>> fetchStockHoldings() async {
    // Check if cached data is available and fresh
    if (cachedStockHoldings != null && cacheTime != null &&
        DateTime.now().difference(cacheTime!) < const Duration(seconds: 60)) {
      // Return cached data if it's within 60 seconds
      return cachedStockHoldings!;
    }

    try {
      // Fetch fresh data from the API
      List<StockHolding> stockHoldings = await _moneyService.fetchStockHoldings();
      
      // Cache the data
      cachedStockHoldings = stockHoldings;
      cacheTime = DateTime.now(); // Update cache time
      
      return stockHoldings;
    } catch (e) {
      print("Error fetching stock holdings in repository: ${e.toString()}");
      throw Exception('Failed to load stock holdings: $e');
    }
  }
}
