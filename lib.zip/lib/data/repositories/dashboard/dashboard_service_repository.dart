import 'package:amplify/data/services/dashboard/dashboard_service.dart';

class DashboardServiceRepository {
  final DashboardService _dashboardService = DashboardService();
  
  Map<String, dynamic>? cachedData;
  DateTime? cacheTime;

  Future<dynamic> fetchDashHouseholdItemsInfo() async {
    if (cachedData != null && cacheTime != null &&
        DateTime.now().difference(cacheTime!) < const Duration(seconds: 120)) {
      // Return cached data if it's within 120 seconds
      return cachedData;
    }

    try {
      // Fetch fresh data from the API
      dynamic details = await _dashboardService.fetchDashHouseholdItemsInfo();
      
      // Cache data
      cachedData = details;
      cacheTime = DateTime.now();
      
      return details;
    } catch (e) {
      throw Exception('Failed to load household details: $e');
    }
  }
}
