class AppConstants {
  static const String clientSecret =
      '2EBE1E4D268FD918BBCE6527E405230F54DD1AA076F79AB0A4064D308A4AC047';

  static const String logoPrefix =
      'https://amplifytestjobstorage.blob.core.windows.net/';

  static const maxMobileWidth = 700;

  static const maxTabWidth = 1280;

  static const String portalUrl = "https://lumsuat.gitait.com/portal/atpw/addepar";

}
