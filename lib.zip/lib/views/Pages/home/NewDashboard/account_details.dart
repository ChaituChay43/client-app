
import 'package:amplify/views/components/home/NewDashboard/balance_card.dart';
import 'package:amplify/views/components/home/NewDashboard/profile_card.dart';
import 'package:amplify/views/components/utilities/account_header.dart';
import 'package:flutter/material.dart';

class AccountDetails extends StatefulWidget {
  const AccountDetails({super.key});

  @override
  _AccountDetailsState createState() => _AccountDetailsState();
}

class _AccountDetailsState extends State<AccountDetails> {
  final List<String> accountNames = ["Rocky Balboa - IRA ROTH", "Rocky Balboa - Indiv", 'Rocky Balboa - SEP'];

  final List<Map<String, dynamic>> accountsData = [
    {
      "accountName": "Rocky Balboa - IRA ROTH",
      "custodian": "Custodian 1",
      "accountNumber": "123456789",
      "totalBalance": 150000.0,
      "today": {"value": 200.0, "percentage": 2.0},
      "mtd": {"value": 500.0, "percentage": 5.0},
      "qtd": {"value": 1500.0, "percentage": 15.0},
      "tyd": {"value": 3000.0, "percentage": 30.0},
    },
    {
      "accountName": "Rocky Balboa - Indiv",
      "custodian": "Custodian 2",
      "accountNumber": "987654321",
      "totalBalance": 537200.0,
      "today": {"value": 400.0, "percentage": 5.0},
      "mtd": {"value": 1000.0, "percentage": 8.0},
      "qtd": {"value": 3000.0, "percentage": 15.0},
      "tyd": {"value": 6000.0, "percentage": 20.0},
    },
    {
      "accountName": "Rocky Balboa - SEP",
      "custodian": "Custodian 2",
      "accountNumber": "987654321",
      "totalBalance": 437200.0,
      "today": {"value": 400.0, "percentage": 5.0},
      "mtd": {"value": 1000.0, "percentage": 8.0},
      "qtd": {"value": 3000.0, "percentage": 15.0},
      "tyd": {"value": 6000.0, "percentage": 20.0},
    },
  ];

  late Map<String, dynamic> selectedAccount = accountsData[0]; // Ensure data is available

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.only(top: 60.0), // Add padding to account for the header height
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Main content section (ProfileCard and BalanceCard)
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        if (constraints.maxWidth > 600) {
                          // Desktop layout
                          return Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  children: [
                                    ProfileCard(account: selectedAccount),
                                    const SizedBox(height: 20),
                                    BalanceCard(account: selectedAccount),
                                  ],
                                ),
                              ),
                            ],
                          );
                        } else {
                          // Mobile layout
                          return Column(
                            children: [
                              ProfileCard(account: selectedAccount),
                              const SizedBox(height: 10),
                              BalanceCard(account: selectedAccount),
                            ],
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Sticky Account Header
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AccountHeader(
              accountName: selectedAccount['accountName'],
              accountNames: accountNames,
              onItemSelected: (String selected) {
                setState(() {
                  selectedAccount = accountsData.firstWhere(
                    (account) => account["accountName"] == selected,
                  );
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}
