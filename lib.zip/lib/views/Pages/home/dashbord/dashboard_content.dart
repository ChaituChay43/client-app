import 'package:amplify/data/repositories/household/household_service_repository.dart';
import 'package:amplify/data/services/household/household_service.dart';
import 'package:amplify/models/response/household/household_res.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:amplify/data/repositories/dashboard/dashboard_service_repository.dart';
import 'package:amplify/models/other/address_info.dart';
import 'package:amplify/models/other/household_info.dart';
import 'package:amplify/views/components/home/dashboard/contact_details.dart';
import 'package:amplify/views/components/utilities/Dashboard_dropdown.dart';

class DashboardContent extends StatefulWidget {
  const DashboardContent({super.key});

  @override
  State<DashboardContent> createState() => _DashboardContentState();
}

class _DashboardContentState extends State<DashboardContent> {
  late DashboardServiceRepository _dashboardServiceRepository;
  late HouseholdServiceRepository _householdRepository;

  dynamic _dashboardDetails;
  HouseholdInfo? householdInfo;
  double totalNetWorth = 0;
  double expensesSumValue = 0;
  bool isLoading = true;
  bool hasError = false;

  @override
  void initState() {
    super.initState();
    _dashboardServiceRepository = DashboardServiceRepository();
    
    HouseholdService householdService = HouseholdService();
    _householdRepository = HouseholdServiceRepository(householdService);
    fetchHouseholdDetails();
  }

  Future<void> fetchHouseholdDetails() async {
    try {
      HouseholdDetail householdDetail = await _householdRepository.fetchHouseholdDetails();
      setState(() {
        isLoading = false;
        hasError = false;
      });
      fetchDashHouseholdItemsInfo(householdDetail);
    } catch (e) {
      setState(() {
        isLoading = false;
        hasError = true;
      });
      print("Error fetching household details: $e");
    }
  }

  Future<void> fetchDashHouseholdItemsInfo(HouseholdDetail householdDetail) async {
    setState(() {
      isLoading = true;
      hasError = false;
    });

    try {
      dynamic dashboardDetails = await _dashboardServiceRepository.fetchDashHouseholdItemsInfo();
      HouseholdInfo? hhInfoResult = await hhInfo(dashboardDetails, householdDetail);
      setState(() {
        _dashboardDetails = dashboardDetails;
        totalNetWorth = assetSumValue();
        expensesSumValue = incomeSumValue();
        householdInfo = hhInfoResult;
        isLoading = false;
      });
    } catch (e) {
      print('Error fetching dashboard details: $e');
      setState(() {
        isLoading = false;
        hasError = true;
      });
    }
  }

  double assetSumValue() {
    double total = 0.0;
    if (_dashboardDetails != null && _dashboardDetails is Map) {
      _dashboardDetails.forEach((key, value) {
        if (value['type']?.toString().startsWith('asset') == true && value['isAsset'] == true) {
          total += (value['val'] ?? 0).toDouble();
        }
      });
    }
    return total;
  }

  double incomeSumValue() {
    double totalIncome = 0.0;
    if (_dashboardDetails != null && _dashboardDetails is Map) {
      _dashboardDetails.values.where((p) => p['type']?.toString().startsWith('income') == true && p['isIncome'] == true).forEach((item) {
        double value = (item['value'] ?? 0).toDouble();
        if (item['periodType'] == 'Y') {
          value /= 12;
        }
        totalIncome += value;
      });
    }
    return totalIncome;
  }

  Future<HouseholdInfo?> hhInfo(dynamic data, HouseholdDetail householdDetail) async {
    if (data != null && data is Map) {
      var primaryMembers = data.values.where((entry) => entry['type'] == 'member:primary' && entry['isDeleted'] != true).toList();
      if (primaryMembers.isNotEmpty) {
        var primaryMember = primaryMembers.first;
        return HouseholdInfo(
          name: householdDetail.name,
          firstAccountOpened: householdDetail.firstAccountOpened,
          riskToleranceScore: householdDetail.riskToleranceScore,
          primaryPhone: primaryMember['pNumber']?.toString().isNotEmpty == true ? primaryMember['pNumber'] : 'N/A',
          primaryEmail: primaryMember['eAddress']?.toString().isNotEmpty == true ? primaryMember['eAddress'] : 'N/A',
          secToken: primaryMember['secToken'] ?? 'N/A',
          householdTags: (primaryMember['householdTags'] ?? []).cast<String>(),
          addresses: (primaryMember['allAddresses'] ?? []).map<Address>((addr) => Address.fromJson(addr)).toList(),
        );
      }
    }
    return null;
  }

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.simpleCurrency(decimalDigits: 2, name: 'USD');
    return formatter.format(amount);
  }

  String _formatDate(DateTime date) {
  final DateFormat formatter = DateFormat('MM/dd/yyyy'); // You can adjust the format as needed.
  return formatter.format(date);
}

String _calculateYearsSince(DateTime startDate) {
  DateTime now = DateTime.now();
  int yearsDifference = now.year - startDate.year;
  if (now.month < startDate.month || (now.month == startDate.month && now.day < startDate.day)) {
    yearsDifference--; // Adjust if we haven't reached the month/day in the current year.
  }
  return yearsDifference.toString();
}

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    } else if (hasError) {
      return const Center(child: Text("An error occurred while loading data"));
    }

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          return constraints.maxWidth > 600 ? _buildWebView() : _buildMobileView();
        },
      ),
    );
  }

  Widget _buildWebView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildUserInfo(),
          const SizedBox(height: 16.0),
          // _buildFinanceSection(),
        ],
      ),
    );
  }

  Widget _buildMobileView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildUserInfo(),
          const SizedBox(height: 16.0),
          // _buildFinanceSection(),
        ],
      ),
    );
  }

  Widget _buildUserInfo() {
    return Card(
      color: Colors.white,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    householdInfo?.name ?? "Unknown",
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                CircleAvatar(
                  backgroundColor: Colors.blue,
                  maxRadius: 20.0,
                  child: DropdownIconButton(
                    icon: const Icon(Icons.filter_alt_rounded, color: Colors.white, size: 25.0),
                    items: const ["Rocky Balboa", "Balboa Adrian", "Michael", "Sophia"],
                    onSelected: (String selected) {
                      print("You selected: $selected");
                    },
                  ),
                ),
              ],
            ),
          ),
          _buildContactDetails(),
          // _buildInvestmentProfile(),
        ],
      ),
    );
  }

  Widget _buildContactDetails() {
  return Padding(
    padding: const EdgeInsets.all(16.0),
    child: LayoutBuilder(
      builder: (context, constraints) {
        bool isWideScreen = constraints.maxWidth > 450;

        // Get 'firstAccountOpened' from householdInfo or fallback to today's date
        DateTime firstAccountDate = householdInfo?.firstAccountOpened ?? DateTime.now();
        String formattedDate = _formatDate(firstAccountDate);
        String yearsSince = _calculateYearsSince(firstAccountDate);

        return Column(
          children: [
            _buildContactDetailRow(
              'Phone', 
              householdInfo?.primaryPhone ?? 'N/A', 
              Icons.phone_in_talk_outlined, 
              isWideScreen
            ),
            const SizedBox(height: 10.0),
            _buildContactDetailRow(
              'Security Token', 
              householdInfo?.secToken ?? 'Not Available', 
              Icons.security, 
              isWideScreen
            ),
            const SizedBox(height: 10.0),
            const Divider(thickness: 1.0),
            const SizedBox(height: 10.0),
            _buildContactDetailRow(
              'Email', 
              householdInfo?.primaryEmail ?? 'N/A', 
              Icons.email, 
              isWideScreen
            ),
            const SizedBox(height: 10.0),
            _buildContactDetailRow(
              'Client Since', 
              '$formattedDate ($yearsSince years)', 
              Icons.access_time, 
              isWideScreen
            ),
          ],
        );
      },
    ),
  );
}
  Widget _buildContactDetailRow(String label, String value, IconData icon, bool isWideScreen) {
    return Row(
      mainAxisAlignment: isWideScreen ? MainAxisAlignment.spaceBetween : MainAxisAlignment.start,
      children: [
        Expanded(
          flex: isWideScreen ? 1 : 0,
          child: ContactDetail(
            label: label,
            value: value,
            icon: icon,
            onTap: () {
              // Add logic for tap
            },
            isWideScreen: isWideScreen,
          ),
        ),
        if (isWideScreen) const SizedBox(width: 16.0),
        if (!isWideScreen) const SizedBox(height: 10.0),
      ],
    );
  }

  // Widget _buildInvestmentProfile() {
  //   return Padding(
  //     padding: const EdgeInsets.symmetric(vertical: 16.0),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         const Text('Investment Profile'),
  //         LayoutBuilder(
  //           builder: (context, constraints) {
  //             bool isWideScreen = constraints.maxWidth > 650;
  //             if (isWideScreen) {
  //               return Row(
  //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                 children: [
  //                   InvestmentProfileItem(
  //                     label: 'Capital Appreciation',
  //                     value: householdInfo?.riskToleranceScore ?? 0,
  //                     circleColor: Colors.red,
  //                     svgData: _getSvgData(),
  //                   ),
  //                   const SizedBox(width: 50.0),
  //                   InvestmentProfileItem(
  //                     label: 'Growth',
  //                     value: householdInfo?.riskToleranceScore ?? 0,
  //                     circleColor: const Color(0xFFE86427),
  //                     svgData: _getSvgData(),
  //                   ),
  //                 ],
  //               );
  //             } else {
  //               return Column(
  //                 children: [
  //                   InvestmentProfileItem(
  //                     label: 'Capital Appreciation',
  //                     value: householdInfo?.riskToleranceScore ?? 0,
  //                     circleColor: Colors.red,
  //                     svgData: _getSvgData(),
  //                   ),
  //                   const SizedBox(height: 50.0),
  //                   InvestmentProfileItem(
  //                     label: 'Growth',
  //                     value: householdInfo?.riskToleranceScore ?? 0,
  //                     circleColor: const Color(0xFFE86427),
  //                     svgData: _getSvgData(),
  //                   ),
  //                 ],
  //               );
  //             }
  //           },
  //         ),
  //       ],
  //     ),
  //   );
  // }

  // String _getSvgData() {
  //   return '''
  //     <svg viewBox="0 0 250 9" xmlns="http://www.w3.org/2000/svg" width="225" height="9">
  //       <rect width="33" height="9" x="0" fill="#16A163" tabindex="0" />
  //       <rect width="33" height="9" x="41.6" fill="#43C478" tabindex="0" />
  //       <rect width="33" height="9" x="83.2" fill="#88DBA8" tabindex="0" />
  //       <rect width="33" height="9" x="124.8" fill="#FC9162" tabindex="0" />
  //       <rect width="33" height="9" x="166.4" fill="#E86427" tabindex="0" />
  //       <rect width="33" height="9" x="208" fill="#FA5343" tabindex="0" />
  //     </svg>
  //   ''';
  // }

  // Widget _buildFinanceSection() {
  //   return LayoutBuilder(
  //     builder: (context, constraints) {
  //       bool isWideScreen = constraints.maxWidth > 700;
  //       return isWideScreen
  //           ? Row(
  //               children: [
  //                 Expanded(
  //                   child: FinanceSectionCard(
  //                     title: 'Total Net Worth',
  //                     mainValue: _formatCurrency(totalNetWorth),
  //                     label1: 'Assets',
  //                     value1: _formatCurrency(totalNetWorth),
  //                     label2: 'Liabilities',
  //                     value2: _formatCurrency(0.00),
  //                   ),
  //                 ),
  //                 const SizedBox(width: 16.0),
  //                 Expanded(
  //                   child: FinanceSectionCard(
  //                     title: 'Income & Expenses',
  //                     mainValue: _formatCurrency(expensesSumValue),
  //                     label1: 'Monthly Income',
  //                     value1: _formatCurrency(expensesSumValue),
  //                     label2: 'Monthly Expenses',
  //                     value2: _formatCurrency(0.00),
  //                   ),
  //                 ),
  //               ],
  //             )
  //           : Column(
  //               children: [
  //                 FinanceSectionCard(
  //                   title: 'Total Net Worth',
  //                   mainValue: _formatCurrency(totalNetWorth),
  //                   label1: 'Assets',
  //                   value1: _formatCurrency(totalNetWorth),
  //                   label2: 'Liabilities',
  //                   value2: _formatCurrency(0.00),
  //                 ),
  //                 const SizedBox(height: 16.0),
  //                 FinanceSectionCard(
  //                   title: 'Income & Expenses',
  //                   mainValue: _formatCurrency(expensesSumValue),
  //                   label1: 'Monthly Income',
  //                   value1: _formatCurrency(expensesSumValue),
  //                   label2: 'Monthly Expenses',
  //                   value2: _formatCurrency(0.00),
  //                 ),
  //               ],
  //             );
  //     },
  //   );
  // }
}
