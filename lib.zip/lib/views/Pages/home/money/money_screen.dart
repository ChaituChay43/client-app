import 'package:amplify/data/repositories/money/money_service_repository.dart';
import 'package:amplify/models/other/asset_data.dart';
import 'package:amplify/models/other/stockdata.dart';
import 'package:amplify/models/response/money/stock_holding.dart';
import 'package:amplify/theme/app_theme.dart';
import 'package:amplify/views/components/home/money/asset_chart.dart';
import 'package:amplify/views/components/home/money/table_component.dart';
import 'package:amplify/views/components/utilities/Dashboard_dropdown.dart';
import 'package:amplify/views/components/utilities/account_header.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class MoneyContent extends StatefulWidget {
  const MoneyContent({super.key});

  @override
  _MoneyContentState createState() => _MoneyContentState();
}

class _MoneyContentState extends State<MoneyContent> {
  late final MoneyServiceRepository _repository;
  late List<StockHolding> stockholdings = []; // Initialize with an empty list
  bool isLoading = true; // Track loading state
  String errorMessage = ''; // To store error messages


  // Dropdown list for holdings
  // List<DropDownType> dropDownTypes = [
  //   DropDownType(value: 0, name: 'Household', selected: true),
  //   DropDownType(value: 1, name: 'Best % Change of Today', selected: false),
  //   DropDownType(value: 2, name: 'Worst % Change of Today', selected: false),
  // ];
    final List<String> accountNames = ["Rocky Balboa - IRA ROTH", "Rocky Balboa - Indiv", 'Rocky Balboa - SEP'];

  final List<Map<String, dynamic>> accountsData = [
    {
      "accountName": "Rocky Balboa - IRA ROTH",
    },
    {
      "accountName": "Rocky Balboa - Indiv",
    },
    {
      "accountName": "Rocky Balboa - SEP",
    },
  ];

  late Map<String, dynamic> selectedAccount = accountsData[0];

  // Dropdown list for asset classes
  final List<String> _assetDropdownItems = [
    'View by asset class',
    'Real Estate',
    'Commodities',
    'Private Equity',
  ];

  String _selectedItem = 'Household'; // Selected Holdings dropdown item
  String _selectedAsset = 'View by asset class'; // Selected Asset Class dropdown item

  // Stock Data for Holdings Section
  List<StockData> allStockData = [
    StockData(symbol: 'AAPL', name: 'Apple Inc.', value: '\$145,123.09', percentage: "1.2"),
    StockData(symbol: 'TSLA', name: 'Tesla Inc.', value: '\$145,232.09', percentage: "-2.4"),
    StockData(symbol: 'GOOGL', name: 'Alphabet Inc.', value: '\$108,123.09', percentage: "3.5"),
    StockData(symbol: 'NFLX', name: 'Netflix Inc.', value: '\$195,123.09', percentage: "-3.9"),
    StockData(symbol: 'META', name: 'Meta Platforms Inc.', value: '\$249,123.09', percentage: "-5.0"),
    StockData(symbol: 'AMZN', name: 'Amazon.com Inc.', value: '\$345,123.09', percentage: "5.6"),
  ];

  // Asset Data for Asset Class Section
  final Map<String, List<AssetData>> assetTableDataMap = {
    'View by asset class': [
      AssetData(name: "Domestic Equities", value: '\$469,730.00', percentage: 48.3),
      AssetData(name: "Cash & Equivalents", value: '\$262,500.00', percentage: 27.0),
      AssetData(name: "Fixed Income", value: '\$176,300.00', percentage: 18.1),
      AssetData(name: "International Equities", value: '\$63,500.00', percentage: 6.5),
    ],
    'Real Estate': [
      AssetData(name: "Real Estate", value: '\$210,000.00', percentage: 20.0),
    ],
    'Commodities': [
      AssetData(name: "Commodities", value: '\$150,000.00', percentage: 15.0),
    ],
    'Private Equity': [
      AssetData(name: "Private Equity", value: '\$510,000.00', percentage: 51.0),
    ]
  };

  final List<ColumnConfig> stockColumns = [
    ColumnConfig(name: 'Symbol', isBold: true, backgroundColor: Colors.lightBlueAccent.withOpacity(0.3)),
    ColumnConfig(name: 'Name', isEllipsis: true),
    ColumnConfig(name: 'Value', textAlign: TextAlign.end, isBold: true, isEllipsis: true),
    ColumnConfig(name: 'percentage', textAlign: TextAlign.end, isBold: true),
  ];
  List<Map<String, Object>> HoldingData=[
  {
    "Name": "Domestic Equities",
    "Value": "\$469,730.00",
    "percentage": 48.3
  },
  {
    "Name": "Cash & Equivalents",
    "Value": "\$262,500.00",
    "percentage": 27.0
  },
  {
    "Name": "Fixed Income",
    "Value": "\$176,300.00",
    "percentage": 18.1
  },
  {
    "Name": "International Equities",
    "Value": "\$63,500.00",
    "percentage": 6.5
  }
];
List<Map<String, String>> Assetdata=[
  {
    "Symbol": "AOA",
    "Name": "BlackRock Institutional Trust Company N.A. - BTC iShares Core Aggressi",
    "Value": "\$2,011,903,872.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "BISIX",
    "Name": "BlackRock International Dividend Fund - Institutional",
    "Value": "\$0.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "BND",
    "Name": "Vanguard Group, Inc. - Vanguard Total Bond Market ETF",
    "Value": "\$108,635,308,032.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "DFDIX",
    "Name": "Delaware Smid Cap Growth Fund Institutional Class",
    "Value": "\$0.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "F",
    "Name": "Ford Motor Co.",
    "Value": "\$43,221,704,704.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "GM",
    "Name": "General Motors Company",
    "Value": "\$55,499,169,792.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "MADCX",
    "Name": "Blackrock Emerging Markets Fund Inc",
    "Value": "\$0.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "NTBIX",
    "Name": "Navigator Tactical Fixed Income I",
    "Value": "\$0.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "ORLY",
    "Name": "O'Reilly Automotive, Inc.",
    "Value": "\$69,913,985,024.00",
    "percentage": "0.00%"
  },
  {
    "Symbol": "RIVN",
    "Name": "Rivian Automotive Inc - Ordinary Shares - Class A",
    "Value": "\$8,543,289,344.00",
    "percentage": "0.00%"
  }
];



  final List<ColumnConfig> assetColumns = [
    ColumnConfig(name: 'Name', textAlign: TextAlign.start, isChange: true, isEllipsis: true),
    ColumnConfig(name: 'Value', textAlign: TextAlign.start, isBold: true, isEllipsis: true),
    ColumnConfig(name: 'percentage', textAlign: TextAlign.start, isBold: true),
  ];

  List<StockData> filteredStockData = []; // Filtered stock data based on dropdown
  List<AssetData> filteredAssetData = []; // Filtered asset data based on dropdown
  // ignore: non_constant_identifier_names
  List <double> ChartValues = [48.3, 27.0, 18.1, 6.5];
   // ignore: non_constant_identifier_names
   List <String> Chartlabels= ['Domestic Equities','Cash', 'Fixed Income','International Equities' ];
    // ignore: non_constant_identifier_names
    List <Color> Chartcolors= [const Color(0xFF0E3D66), const Color(0xFF43C478), const Color(0xFF1195D6), const Color(0xFF08548A)];// Filtered asset data based on asset

  // Initialize the filtered data with the default selections
  @override
  void initState() {
    super.initState();
    _repository = MoneyServiceRepository();
    fetchHouseholdDetails();
    _onItemSelected(_selectedItem);
  }

  Future<void> fetchHouseholdDetails() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      stockholdings = await _repository.fetchStockHoldings();
      print("Fetched stock holdings from money screen: $stockholdings");
      if (stockholdings.isEmpty) {
        errorMessage = "No stock holdings found.";
      } else {
        // Map stock holdings to your StockData model (assuming such a mapping exists)
        // filteredStockData = stockholdings.map((holding) => StockData(...)).toList();
      }
    } catch (e) {
      errorMessage = "Error fetching stock holdings: $e";
    } finally {
      setState(() {
        isLoading = false;
        _applyFilters(); // Apply filters after fetching
      });
    }
  }

void _applyFilters() async {
  setState(() {
    // Clear the previous filtered data
    filteredStockData = [];
   
  });

  // Fetch stock holdings from the repository
  var stockHoldings = await _repository.fetchStockHoldings(); 

  setState(() {
    // Create a NumberFormat instance for currency formatting
    var currencyFormatter = NumberFormat.currency(symbol: '\$');
    // Create a NumberFormat instance for percentage formatting
    var percentageFormatter = NumberFormat('0.00%'); // For two decimal percentage

    // Filter Stock Data based on the _selectedItem
   // Function to create StockData from a holding
StockData _createStockData( holding) {
  return StockData(
    symbol: holding.symbol,
    name: holding.companyName,
    value: currencyFormatter.format(holding.marketCap ?? 0), // Format as currency
    percentage: holding.percOfBook != null 
        ? percentageFormatter.format(holding.percOfBook! / 100) 
        : '0.00%', // Format percentage with fallback
  );
}

// Debug function to print current filtered stock holdings
void _printFilteredData(String label, List<StockData> data) {
  print('$label: ${data.length} items');
  for (var stock in data) {
    print('Symbol: ${stock.symbol}, Name: ${stock.name}, Value: ${stock.value}, Percentage: ${stock.percentage}');
  }
}

// Filtering and adding stock data based on the selected item
switch (_selectedItem) {
  case 'Household':
    for (var holding in stockHoldings) {
      filteredStockData.add(_createStockData(holding));
    }
    _printFilteredData('Household', filteredStockData); // Debug
    break;

  case 'Best % Change of Today':
    filteredStockData = stockHoldings
        .where((holding) {
          // Ensure percOfBook is not null and greater than 0
          return holding.percOfBook != null && holding.percOfBook! > 0;
        })
        .map((holding) => _createStockData(holding))
        .toList();

    _printFilteredData('Best % Change of Today', filteredStockData); // Debug
    break;

  case 'Worst % Change of Today':
    filteredStockData = stockHoldings
        .where((holding) {
          // Ensure percOfBook is not null and less than 0
          return holding.percOfBook != null && holding.percOfBook! < 0;
        })
        .map((holding) => _createStockData(holding))
        .toList();

    _printFilteredData('Worst % Change of Today', filteredStockData); // Debug
    break;

  default:
    filteredStockData.clear(); // Optional: Reset data if no valid selection
    break;
}


    // Filter Asset Data based on the _selectedAsset
    switch (_selectedAsset) {
      case  'Real Estate' ||  'Commodities' ||  'Private Equity':
        ChartValues = [100.0];
        Chartcolors=[AppTheme.primaryColor];
        Chartlabels=[_selectedAsset];
        break;
      case 'View by asset class':
       ChartValues=[48.3, 27.0, 18.1, 6.5];
       Chartcolors=[const Color(0xFF0E3D66), const Color(0xFF43C478), const Color(0xFF1195D6), const Color(0xFF08548A)];
       Chartlabels=['Domestic Equities','Cash', 'Fixed Income','International Equities' ];
    }
    filteredAssetData = assetTableDataMap[_selectedAsset] ?? [];
  });
}

  // Update filters when dropdowns are changed
  void _onItemSelected(String value) {
    setState(() {
      _selectedItem = value;
      _applyFilters();
    });
  }

  void _onAssetItemSelected(String value) {
    setState(() {
      _selectedAsset = value;
      _applyFilters();
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 60.0), // Offset by the height of the sticky header
            child: isLoading
                ? const Center(child: CircularProgressIndicator()) // Loading indicator
                : errorMessage.isNotEmpty
                    ? Center(child: Text(errorMessage)) // Error message
                    : ListView(
                        children: [
                          _buildAssetClassSection(),
                          const SizedBox(height: 20.0),
                          _buildHoldingsSection(),
                        ],
                      ),
          ),
           Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AccountHeader(
              accountName: selectedAccount['accountName'],
              accountNames: accountNames,
              onItemSelected: (String selected) {
                setState(() {
                  selectedAccount = accountsData.firstWhere(
                    (account) => account["accountName"] == selected,
                  );
                });
              },
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildAssetClassSection() {
    return Card(
      elevation: 5.0,
      child: Container(
        constraints: const BoxConstraints(maxHeight: 650),
        color: Colors.white,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  bool isWideScreen = constraints.maxWidth > 400;
                  return isWideScreen
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const Text(
                              'Asset Class Chart',
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            // _buildDropdownAsset(),
                          ],
                        )
                      : Column(
                          children: [
                            const Text(
                              'Asset Class Chart',
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10.0),
                            // _buildDropdownAsset(),
                          ],
                        );
                },
              ),
            ),
            DoughnutChartWithHover(
              values: ChartValues,
              labels: Chartlabels,
              colors: Chartcolors
            ),
            Expanded(
              child: ReusableTable(
                tableData:  HoldingData,
                columns: assetColumns,
                colors:Chartcolors
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdownAsset() {
    return Container(
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(15.0),
    border: Border.all(color: Colors.grey, width: 1.0),
    color: const Color(0xFFECECEC),
  ),
  child: Row(
    mainAxisSize: MainAxisSize.min,  // This ensures the Row only takes as much space as needed
    children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(_selectedAsset),
      ),
      DropdownIconButton(
        icon: const Icon(Icons.keyboard_arrow_down_sharp, color: AppTheme.primaryColor),
        items: _assetDropdownItems,
        onSelected: _onAssetItemSelected,
        maxHeight: 150.0,
      ),
    ],
  ),
);

  }

  Widget _buildHoldingsSection() {
    return Card(
      elevation: 10.0,
      child: Container(
        constraints: const BoxConstraints(maxHeight: 450),
        color: Colors.white,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Holdings',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  // Container(
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(15.0),
                  //     border: Border.all(color: Colors.grey, width: 1.0),
                  //     color: const Color(0xFFECECEC),
                  //   ),
                  //   child: Row(
                  //     children: [
                  //       Padding(
                  //         padding: const EdgeInsets.all(8.0),
                  //         child: Text(_selectedItem),
                  //       ),
                  //       DropdownIconButton(
                  //         icon: const Icon(Icons.keyboard_arrow_down_sharp, color: AppTheme.primaryColor),
                  //         items: dropDownTypes.map((e) => e.name).toList(),
                  //         onSelected: _onItemSelected,
                  //         maxHeight: 150.0,
                  //       ),
                  //     ],
                  //   ),
                  // ),
                ],
              ),
            ),
            Expanded(
              child: ReusableTable(
                tableData: Assetdata,
                columns: stockColumns,
                colors: [],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
