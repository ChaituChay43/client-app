import 'package:amplify/data/repositories/household/household_service_repository.dart';
import 'package:amplify/data/services/household/household_service.dart';
import 'package:amplify/models/response/household/household_res.dart';
import 'package:amplify/views/components/home/household/HistoryGraph.dart';
import 'package:amplify/views/components/home/household/account_card_widget.dart';
import 'package:amplify/views/components/home/household/summary_card.dart';
import 'package:amplify/views/components/home/money/asset_chart.dart';
import 'package:amplify/views/components/home/money/table_component.dart';
import 'package:flutter/material.dart';

class HouseholdScreen extends StatefulWidget {
  const HouseholdScreen({super.key});

  @override
  State<HouseholdScreen> createState() => _HouseholdScreenState();
}

class _HouseholdScreenState extends State<HouseholdScreen> {
  late HouseholdServiceRepository _repository;

  List<Account> accounts = [];
  List<Map<String, dynamic>> staticAccounts = [
    {
      "iid": 103382,
      "id": "d29c5978-2286-49c4-ab09-118632998943",
      "Name": "Rocky Balboa - IRA ROTH",
      "number": "002200M",
      "custodian": "Manual Account",
      "balance": 150000.0,
    },
    {
      "iid": 104512,
      "id": "0d23c658-e42c-48d4-8319-05352cd21e05",
      "Name": "Rocky Balboa - Indiv",
      "number": "9004141M",
      "custodian": "Manual Account",
      "balance": 537200.0,
    },
    {
      "iid": 104552,
      "id": "00fd809c-2b99-43f5-83d0-e5ed4303f148",
      "Name": "Rocky Balboa - SEP",
      "number": "069960M",
      "custodian": "Manual Account",
      "balance": 284830.0,
    }
  ];
  List<double> ChartValues = [46.6, 37.6, 8.2, 5.2,1.3,0.8,0.3,0.1];
  List<Color> Chartcolors = [
    const Color(0xFF0E3D66),
    const Color(0xFF43C478),
    const Color(0xFF3D8DF5),  // rgb(61, 141, 245)
    const Color(0xFF08548A),  // rgb(8, 84, 138)
    const Color(0xFF7681FC),  // rgb(118, 129, 252)
    const Color(0xFF8BD3F7),  // rgb(139, 211, 247)
    const Color(0xFF075E45),  // rgb(7, 94, 69)
    const Color(0xFFF7B7E2),  // rgb(247, 183, 226)
  ];
  List<String> Chartlabels = [
   'Cash & Equivalents',
   'Domestic Equities',
   'To Be Classified',
   'Fixed Income',
   'International Equities',
   'Real Estate Securities',
   'Alternative Investments',
   'Unclassified'
  ];

    final List<ColumnConfig> assetColumns = [
    ColumnConfig(name: 'Name', textAlign: TextAlign.start, isChange: true, isEllipsis: true),
    ColumnConfig(name: 'Value', textAlign: TextAlign.start, isBold: true, isEllipsis: true),
    ColumnConfig(name: 'percentage', textAlign: TextAlign.start, isBold: true),
  ];

  double netWorth = 972030.0;

  bool isLoading = true; // Track loading state
  bool hasError = false; // Track if there's an error
   List<Map<String, Object>> filteredAssetData= [
    {
      "Name": "Cash & Equivalents",
      "Value": "\$4,754,648.00",
      "percentage": 46.6
    },
    {
      "Name": "Domestic Equities",
      "Value": "\$3,834,723.39",
      "percentage": 37.6
    },
    {
      "Name": "To Be Classified",
      "Value": "\$836,316.81",
      "percentage": 8.2
    },
    {
      "Name": "Fixed Income",
      "Value": "\$534,826.08",
      "percentage": 5.2
    },
    {
      "Name": "International Equities",
      "Value": "\$135,784.32",
      "percentage": 1.3
    },
    {
      "Name": "Real Estate Securities",
      "Value": "\$77,365.61",
      "percentage": 0.8
    },
    {
      "Name": "Alternative Investments",
      "Value": "\$26,445.05",
      "percentage": 0.3
    },
    {
      "Name": "Unclassified",
      "Value": "\$10,024.32",
      "percentage": 0.1
    }
  ] ;
  @override
  void initState() {
    super.initState();
    HouseholdService householdService = HouseholdService();
    _repository = HouseholdServiceRepository(householdService);
    fetchHouseholdDetails();
  }

  Future<void> fetchHouseholdDetails() async {
    try {
      HouseholdDetail householdDetail = await _repository.fetchHouseholdDetails();
      setState(() {
        accounts = householdDetail.accounts;
        netWorth = householdDetail.netWorth;
        isLoading = false;
        hasError = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
        hasError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.all(10.0),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15.0),
              topRight: Radius.circular(15.0),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                offset: const Offset(0, 4),
                blurRadius: 4.0,
                spreadRadius: 1.0,
              ),
            ],
            color: Colors.white,
          ),
          child: Column(
            children: [
              // Header Section
              SummaryCard(
                title: "Balboa, Rocky & Adrian",
                totalAmount: '\$$netWorth',
              ),
              
              // History Graph and Chart Sections
              Container(height: 350.0, child: HistoryGraph()),
              Container(
                height:600.0,
                child: Column(
                  children: [
                    DoughnutChartWithHover(
                      values: ChartValues,
                      labels: Chartlabels,
                      colors: Chartcolors,
                    ),
                     Expanded(
                      child: ReusableTable(
                        tableData: filteredAssetData,
                        columns: assetColumns,
                        colors: Chartcolors,
                      ),
                    ),
                  ],
                ),
              ),

              // Summary Card
              SummaryCard(
                title: "Accounts Summary",
                totalAmount: '',
              ),
              const SizedBox(height: 10),

              // Account List Section
              if (isLoading)
                const Center(child: CircularProgressIndicator())
              else if (hasError)
                Column(
                  children: staticAccounts.map((account) {
                    return Column(
                      children: [
                        AccountCard(
                          title: account['Name'],
                          subtitle: '${account['custodian']}  -  ${account['Name'].split('-').last} -  ${account['number']}',
                          amount: '\$${account['balance']}',
                          onTap: () {},
                        ),
                        const Divider(
                          endIndent: 20.0,
                          thickness: 1.0,
                          indent: 20.0,
                        ),
                      ],
                    );
                  }).toList(),
                )
              else if (accounts.isEmpty)
                const Center(child: Text('No accounts available'))
              else
                Column(
                  children: accounts.map((account) {
                    return Column(
                      children: [
                        AccountCard(
                          title: account.name,
                          subtitle: '${account.custodian}  -  ${account.name.split('-').last} -  ${account.number}',
                          amount: '\$${account.balance}',
                          onTap: () {},
                        ),
                        const Divider(
                          endIndent: 20.0,
                          thickness: 1.0,
                          indent: 20.0,
                        ),
                      ],
                    );
                  }).toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }

  _buildRow(IconData icon, String label, String Value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(icon, color: Colors.blue),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        Text(Value),
      ],
    );
  }
}
