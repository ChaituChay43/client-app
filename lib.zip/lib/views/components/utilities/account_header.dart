import 'package:flutter/material.dart';
import 'package:amplify/views/components/utilities/Dashboard_dropdown.dart';

class AccountHeader extends StatelessWidget {
  final String accountName;
  final List<String> accountNames;
  final void Function(String) onItemSelected;

  const AccountHeader({
    super.key,
    required this.accountName,
    required this.accountNames,
    required this.onItemSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CircleAvatar(
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
            child: Text(accountName[0]),
          ),
          Text(accountName,style: const TextStyle(fontWeight: FontWeight.bold,fontSize: 20.0),),
          DropdownIconButton(
            icon: const Icon(Icons.filter_alt_rounded, color: Colors.blue, size: 25.0),
            items: accountNames,
            onSelected: onItemSelected,
          ),
        ],
      ),
    );
  }
}
