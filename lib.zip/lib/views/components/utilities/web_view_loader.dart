import 'package:amplify/views/components/platform/web_url_loader.dart';
import 'package:flutter/material.dart';

class WebViewLoader extends StatelessWidget {
  final String url;
  final Map<String, String> headers;

  const WebViewLoader({super.key, required this.url, this.headers = const {}});

  @override
  Widget build(BuildContext context) {
      return WebUrlLoader(url: url, headers: headers);
  }
}
