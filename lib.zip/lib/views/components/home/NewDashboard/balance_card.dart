import 'package:amplify/constants/asset_paths.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class BalanceCard extends StatelessWidget {
  final Map<String, dynamic> account; // Define account as a final field

  const BalanceCard({super.key, required this.account}); // Constructor accepting account

  @override
  Widget build(BuildContext context) {
    // Destructure account object to extract necessary values
    final double totalBalance = account['totalBalance'];
    final today = account['today'];
    final mtd = account['mtd'];
    final qtd = account['qtd'];
    final tyd = account['tyd'];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Main card for total balance
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Total Balance',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
              const SizedBox(height: 10.0),
              Row(
                children: [
                  SvgPicture.asset(AssetPaths.accountDetailsMoney),
                  const SizedBox(width: 10.0),
                  Text(
                    '\$${totalBalance.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 24),
                  ),
                ],
              ),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
        // Cards for Today, MTD, QTD, and YTD
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('Today', '\$${today['value'].toStringAsFixed(2)}', '${today['percentage']}%'),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('MTD', '\$${mtd['value'].toStringAsFixed(2)}', '${mtd['percentage']}%'),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('QTD', '\$${qtd['value'].toStringAsFixed(2)}', '${qtd['percentage']}%'),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: balanceCard('YTD', '\$${tyd['value'].toStringAsFixed(2)}', '${tyd['percentage']}%'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget balanceCard(String title, String amount, String percentage) {
    return Container(
      width: 150.0,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3), // changes the shadow position
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min, // Ensure the container only grows to fit its content
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 20.0),
          ),
          const SizedBox(height: 10.0),
          Row(
            mainAxisSize: MainAxisSize.min, // Prevents Row from taking full width
            children: [
              Text(
                amount,
                style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 10.0), // Reduced spacing between amount and percentage
              Container(
                padding: const EdgeInsets.all(4.0),
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  color: Color(0xFFEBF7ED),
                ),
                child: Text(
                  percentage,
                  style: const TextStyle(
                    fontSize: 10.0,
                    color: Color(0xFF077D55),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
