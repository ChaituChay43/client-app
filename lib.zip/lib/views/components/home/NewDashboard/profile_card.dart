import 'package:flutter/material.dart';

class ProfileCard extends StatelessWidget {
  final Map<String, dynamic> account;

  const ProfileCard({super.key, required this.account});
   
  @override
  Widget build(BuildContext context) {
    // Destructure the account object
    String accountName = account['accountName'];
    String custodian = account['custodian'];
    String accountNumber = account['accountNumber'];
    double totalBalance = account['totalBalance'];

    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3), // changes the shadow position
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Stack(
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.blue,
                    child: Text(
                      accountName[0], // First letter of the account name
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    accountName,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Properties in a Wrap, 2 per row
          Wrap(
            spacing: 50,
            runSpacing: 10,
            children: [
              propertyRow('Type', 'Investment'),
              propertyRow('Tax Status', 'Taxable'),
              propertyRow('APM Avail. Cash', '\$${totalBalance.toStringAsFixed(2)}'),
              propertyRow('Custodian', custodian),
              propertyRow('Account', accountNumber),
              propertyRow('Open', '03/23/2023'),
            ],
          ),
        ],
      ),
    );
  }

  Widget propertyRow(String label, String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$label: '),
        Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
