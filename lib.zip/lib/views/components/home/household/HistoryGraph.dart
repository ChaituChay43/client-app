import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class HistoryGraph extends StatefulWidget {
  @override
  _HistoryGraphState createState() => _HistoryGraphState();
}

class _HistoryGraphState extends State<HistoryGraph> {
  String selectedRange = 'ALL'; // Default to ALL
  final List<Map<String, dynamic>> data = [
  {"monthStart": "2018-03-01T00:00:00", "emv": 3136614.5},
  {"monthStart": "2018-04-01T00:00:00", "emv": 3147091.25},
  {"monthStart": "2018-05-01T00:00:00", "emv": 3169002.5},
  {"monthStart": "2018-06-01T00:00:00", "emv": 3206010.0},
  {"monthStart": "2018-07-01T00:00:00", "emv": 3266223.75},
  {"monthStart": "2018-08-01T00:00:00", "emv": 3318046.25},
  {"monthStart": "2018-09-01T00:00:00", "emv": 3300720.0},
  {"monthStart": "2018-10-01T00:00:00", "emv": 3141009.5},
  {"monthStart": "2018-11-01T00:00:00", "emv": 3152674.0},
  {"monthStart": "2018-12-01T00:00:00", "emv": 2989168.0},
  {"monthStart": "2019-01-01T00:00:00", "emv": 3107577.0},
  {"monthStart": "2019-02-01T00:00:00", "emv": 3142688.5},
  {"monthStart": "2019-03-01T00:00:00", "emv": 3181032.0},
  {"monthStart": "2019-04-01T00:00:00", "emv": 3246499.5},
  {"monthStart": "2019-05-01T00:00:00", "emv": 3115681.25},
  {"monthStart": "2019-06-01T00:00:00", "emv": 3220670.75},
  {"monthStart": "2019-07-01T00:00:00", "emv": 3245411.75},
  {"monthStart": "2019-08-01T00:00:00", "emv": 3229943.5},
  {"monthStart": "2019-10-01T00:00:00", "emv": 3221780.0},
  {"monthStart": "2019-11-01T00:00:00", "emv": 5267812.0},
  {"monthStart": "2020-01-01T00:00:00", "emv": 5492330.5},
  {"monthStart": "2020-02-01T00:00:00", "emv": 6268529.0},
  {"monthStart": "2020-03-01T00:00:00", "emv": 6038557.0},
  {"monthStart": "2020-04-01T00:00:00", "emv": 6072481.0},
  {"monthStart": "2020-05-01T00:00:00", "emv": 6788294.5},
  {"monthStart": "2020-06-01T00:00:00", "emv": 6942321.0},
  {"monthStart": "2020-07-01T00:00:00", "emv": 8172177.0},
  {"monthStart": "2020-08-01T00:00:00", "emv": 8474020.0},
  {"monthStart": "2020-09-01T00:00:00", "emv": 8270135.0},
];

  List<FlSpot> chartData = [];
  
  List<Map<String, dynamic>> requiredData=[];

  @override
  void initState() {
    super.initState();
    updateChartData('ALL');
      requiredData = data.asMap().entries.map((entry) {
  int index = entry.key; // Get the index
  Map<String, dynamic> value = entry.value; // Get the actual map

  double emv = value['emv'];
  
  // Convert the emv to a string and extract the first two digits
  String emvString = emv.toStringAsFixed(0).replaceAll('.', '');
  String firstTwoDigits = emvString.substring(0, 2);

  // Convert the first two digits back to a number and divide by 10
  double convertedEmv = int.parse(firstTwoDigits) / 10;

  // Return the modified entry with the index as the "monthStart"
  return {
    "monthStart": index,  // Using index instead of monthStart
    "emv": convertedEmv,
  };
}).toList();
  }

  // Method to update chart data based on selected range double.parse(e['emv'].toStringAsFixed(1))))
  void updateChartData(String range) {
    setState(() {
      selectedRange = range;
      if (range == 'YTD') {
        
        chartData = [
          FlSpot(0, 3.2), // Oct 19
          FlSpot(1, 3.1), // Nov 19
          FlSpot(2, 3.2), // Dec 19
          FlSpot(3, 3.5), // Jan 20
          FlSpot(4, 3.8), // Feb 20
          FlSpot(5, 4.2), // Mar 20
          FlSpot(6, 4.5), // Apr 20
          FlSpot(7, 4.8), // May 20
          FlSpot(8, 5.0), // Jun 20
          FlSpot(9, 5.2), // Jul 20
          FlSpot(10, 5.3), // Aug 20
          FlSpot(11, 5.4), // Sep 20
          FlSpot(12, 5.5), // Oct 20
        ]; 
      } else if (range == '1Y') {
        // Show data from Oct 2019 to Oct 2020 with 1-month gap
        chartData = [
          FlSpot(0, 3.2), // Oct 19
          FlSpot(1, 3.1), // Nov 19
          FlSpot(2, 3.2), // Dec 19
          FlSpot(3, 3.5), // Jan 20
          FlSpot(4, 3.8), // Feb 20
          FlSpot(5, 4.2), // Mar 20
          FlSpot(6, 4.5), // Apr 20
          FlSpot(7, 4.8), // May 20
          FlSpot(8, 5.0), // Jun 20
          FlSpot(9, 5.2), // Jul 20
          FlSpot(10, 5.3), // Aug 20
          FlSpot(11, 5.4), // Sep 20
          FlSpot(12, 5.5), // Oct 20
        ];
      } else if (range == 'ALL') {
        // Show data from Apr 2018 to Oct 2020 with 4-month gap
        chartData = [
          FlSpot(0, 2.5), // Apr 18
          FlSpot(1, 2.6), // Aug 18
          FlSpot(2, 2.7), // Dec 18
          FlSpot(3, 2.8), // Apr 19
          FlSpot(4, 3.0), // Aug 19
          FlSpot(5, 3.5), // Dec 19
          FlSpot(6, 4.0), // Apr 20
          FlSpot(7, 5.0), // Aug 20
          FlSpot(8, 5.5), // Oct 20
        ];
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          
          children: [
             Text("Portfolio Balance History",style: TextStyle(fontFamily:"Roboto",fontSize: 20.0,color: Colors.black),),
            // Buttons for selecting time range
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                 
                  ElevatedButton(
                    onPressed: () => updateChartData('YTD'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedRange == 'YTD' ? Colors.blue : Colors.grey,
                    ),
                    child: Text("YTD"),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: () => updateChartData('1Y'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedRange == '1Y' ? Colors.blue : Colors.grey,
                    ),
                    child: Text("1Y"),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: () => updateChartData('ALL'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedRange == 'ALL' ? Colors.blue : Colors.grey,
                    ),
                    child: Text("ALL"),
                  ),
                ],
              ),
            ),
            // Chart displaying data
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: LineChart(
                  LineChartData(
                    lineBarsData: [
                      LineChartBarData(
                        spots: chartData,
                        isCurved: true,
                        color: Colors.blue,
                        barWidth: 3,
                        belowBarData: BarAreaData(
                          show: true,
                          color: Colors.blue.withOpacity(0.3),
                        ),
                        dotData: FlDotData(show: true),
                      ),
                    ],
                    titlesData: FlTitlesData(
                      show: true,
                      topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)), // Hide top titles
                      rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)), // Hide right titles
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          interval: (selectedRange == 'ALL') ? 4 : 1, // Adjust interval based on range
                          getTitlesWidget: (value, meta) {
                            if (selectedRange == 'YTD') {
                              return Text(
                                ['Jan 20', 'Feb 20', 'Mar 20', 'Apr 20', 'May 20', 'Jun 20', 'Jul 20', 'Aug 20', 'Sep 20', 'Oct 20',
                                'Jan 20', 'Feb 20', 'Mar 20', 'Apr 20', 'May 20', 'Jun 20', 'Jul 20', 'Aug 20', 'Sep 20', 'Oct 20'][value.toInt()],
                                style: TextStyle(color: Colors.black),
                              );
                            } else if (selectedRange == '1Y') {
                              return Text(
                                ['Oct 19', 'Nov', '', 'Jan 20', '', '', 'Apr 20', '', '', 'Jul 20', '', '', 'Oct 20'][value.toInt()],
                                style: TextStyle(color: Colors.black),
                              );
                            } else if (selectedRange == 'ALL') {
                              return Text(
                                ['Apr 18', '', '', 'Apr 19', '', '', 'Apr 20', '', 'Oct 20'][value.toInt()],
                                style: TextStyle(color: Colors.black),
                              );
                            }
                            return Text('');
                          },
                        ),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 40,
                          interval: 2, // Adjust interval as needed
                          getTitlesWidget: (value, meta) {
                            return Text('${value.toInt()} M', style: TextStyle(color: Colors.black));
                          },
                        ),
                      ),
                    ),
                    borderData: FlBorderData(
                      show: true,
                      border: Border.all(color: Colors.grey),
                    ),
                    gridData: FlGridData(show: true),
                    minX: 0,
                    maxX: (selectedRange == 'YTD') ? 9 : (selectedRange == '1Y') ? 12 : 8,
                    minY: 0,
                    maxY: 10,
                  ),
                ),
              ),
            ),
          ],
        ),
    );
  }
}
