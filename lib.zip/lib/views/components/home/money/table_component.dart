import 'package:amplify/constants/asset_paths.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class ColumnConfig {
  final String name;
  final int flex;
  final TextAlign textAlign;
  final bool isBold;
  final bool isEllipsis;
  final Color backgroundColor;
  final bool isChange;
  final Color smallboxColor;

  ColumnConfig({
    required this.name,
    this.flex = 1,
    this.textAlign = TextAlign.center,
    this.isBold = false,
    this.isEllipsis = false,
    this.backgroundColor = Colors.transparent,
    this.smallboxColor = Colors.red,
    this.isChange = false,
  });
}

class ReusableTable extends StatelessWidget {
  final List<Map<String, dynamic>> tableData;
  final List<ColumnConfig> columns;
  final List<Color> colors; // Dynamically received colors

  const ReusableTable({
    required this.tableData,
    required this.columns,
    required this.colors, // Accept colors as an incoming property
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    print(tableData);
    columns.fold<int>(0, (sum, column) => sum + column.flex);

    return Container(
      padding: const EdgeInsets.all(18.0),
      child: tableData.isEmpty
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.15),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: SvgPicture.asset(
                    AssetPaths.noData,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'No items to display',
                  style: TextStyle(fontSize: 18, color: Colors.black),
                ),
              ],
            )
          : Column(
              children: [
                // Table Headers
                Row(
                  children: columns.map((column) {
                    return Expanded(
                      flex: column.flex,
                      child: Center(
                        child: Text(
                          column.name,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                          overflow: column.isEllipsis ? TextOverflow.ellipsis : null,
                          textAlign: column.textAlign,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const Divider(thickness: 1),
                // Expanding ListView to take the remaining space
                Expanded(
                  child: ListView.separated(
                    itemCount: tableData.length,
                    separatorBuilder: (BuildContext context, int index) {
                      return const Divider();
                    },
                    itemBuilder: (BuildContext context, int index) {
                      final item = tableData[index];
                      return Row(
                        children: columns.map((column) {
                          return Expanded(
                            flex: column.flex,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                padding: const EdgeInsets.all(10.0),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      const BorderRadius.all(Radius.circular(10.0)),
                                  color: column.backgroundColor,
                                ),
                                child: Center(
                                  child: column.isChange
                                      ? Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius: const BorderRadius.all(
                                                    Radius.circular(1.0)),
                                                color: colors[index % colors.length], // Use dynamic colors
                                              ),
                                              margin:
                                                  const EdgeInsets.only(right: 10.0),
                                              child: const SizedBox(
                                                height: 10.0,
                                                width: 10.0,
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                item[column.name]?.toString() ?? '',
                                                style: TextStyle(
                                                  fontWeight: column.isBold
                                                      ? FontWeight.bold
                                                      : FontWeight.normal,
                                                ),
                                                overflow: column.isEllipsis
                                                    ? TextOverflow.ellipsis
                                                    : TextOverflow.visible,
                                                textAlign: column.textAlign,
                                              ),
                                            ),
                                          ],
                                        )
                                      : Text(
                                          item[column.name]?.toString() ?? '',
                                          style: TextStyle(
                                              fontWeight: column.isBold
                                                  ? FontWeight.bold
                                                  : FontWeight.normal,
                                              fontSize: 13.0),
                                          overflow: column.isEllipsis
                                              ? TextOverflow.ellipsis
                                              : null,
                                          textAlign: column.textAlign,
                                        ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
